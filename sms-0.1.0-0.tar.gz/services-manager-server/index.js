const Express = require('express');
const ServicesManagerServer = Express();

ServicesManagerServer.get('/', (request, response) => response.send('Hello World!'));

ServicesManagerServer.listen(9090, () => console.log('ServicesManagerServer listening on port 9090'));


